import{s as p}from"./index-gb5rO_47.js";import{b as _}from"./brand-email-template-DJCW2Q4y.js";import{o as b}from"./whatsapp-HR2ZZwps.js";import{bv as T}from"./ui-vendor-DIQMAUfz.js";function $(t,e,i){const r=(t==null?void 0:t.name)||"Assay Biz",l=e!=null&&e.amount?`₹${Number(e.amount).toLocaleString("en-IN")}`:"Confirmed";return _({logoUrl:(t==null?void 0:t.logo_url)||"https://aassaybiz.com/email-logo.png",companyName:r,companyEmail:(t==null?void 0:t.email)||"support@aassaybiz.com",badgeText:"DEAL WON · ONBOARDING CONFIRMED",title:"Congratulations & Welcome Aboard!",subtitle:`We are thrilled to officially welcome you to ${r}`,recipientName:i.name,introText:`Thank you for choosing ${r}! We are honored by your trust and partnership. Your deal has been officially confirmed, and our team is already preparing to deliver an outstanding experience.`,amountLabel:"Deal Value",amountValue:l,details:[{label:"Deal Title",value:e.title||"Sales Partnership"},{label:"Status",value:"Won & Confirmed",isHighlight:!1},{label:"Partner Company",value:r},{label:"Confirmation Date",value:new Date().toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"})}],customBodyHtml:`
      <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; margin: 20px 0;">
        <h3 style="margin: 0 0 12px; font-size: 15px; font-weight: 700; color: #0f172a; display: flex; align-items: center; gap: 8px;">
          🚀 What happens next?
        </h3>
        <ol style="margin: 0; padding-left: 20px; color: #475569; font-size: 14px; line-height: 1.7;">
          <li style="margin-bottom: 6px;"><strong>Dedicated Onboarding:</strong> Our account manager will initiate your kickoff within 24 hours.</li>
          <li style="margin-bottom: 6px;"><strong>Documentation & Scope:</strong> All deliverables, milestones, and shared resources are being organized.</li>
          <li><strong>Direct Support Line:</strong> You have priority access to our support desk whenever you need assistance.</li>
        </ol>
      </div>

      <div style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); border-radius: 12px; padding: 18px; text-align: center; border: 1px solid #bfdbfe; margin-top: 16px;">
        <p style="margin: 0 0 4px; font-size: 13px; font-weight: 600; color: #1e40af;">HAVE QUESTIONS OR NEED IMMEDIATE HELP?</p>
        <p style="margin: 0; font-size: 14px; color: #1e3a8a;">
          Reach out directly to us at <strong>${(t==null?void 0:t.email)||"support@aassaybiz.com"}</strong>
          ${t!=null&&t.phone?` or call <strong>${t.phone}</strong>`:""}
        </p>
      </div>
    `})}function w(t,e,i){const r=(t==null?void 0:t.name)||"Assay Biz",l=e!=null&&e.amount?`₹${Number(e.amount).toLocaleString("en-IN")}`:"Confirmed",n=(t==null?void 0:t.phone)||(t==null?void 0:t.company_phone)||"our support desk";return`🎉 *Congratulations & Welcome to ${r}!*

Dear *${i.name||"Valued Client"}*,

We are delighted to confirm that your deal *"${(e==null?void 0:e.title)||"Partnership"}"* is now officially *Won & Confirmed*! 🚀

💼 *Deal Value:* ${l}
🏢 *Partner:* ${r}
📅 *Date:* ${new Date().toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"})}

We are truly honored to partner with you and are dedicated to your complete success and satisfaction.

👉 *Next Steps:*
• Our onboarding specialist will reach out to you shortly.
• Your dedicated services are now being activated.
• Feel free to reply directly to this WhatsApp message anytime!

📞 *Need immediate assistance?*
Contact: ${n} | ${(t==null?void 0:t.email)||"support@aassaybiz.com"}

Warm regards,
*Team ${r}*`}function x(t,e){const i=(t==null?void 0:t.name)||"Assay Biz";return _({logoUrl:(t==null?void 0:t.logo_url)||"https://aassaybiz.com/email-logo.png",companyName:i,companyEmail:(t==null?void 0:t.email)||"support@aassaybiz.com",badgeText:"CRM WELCOME",title:`Welcome, ${e.name}!`,subtitle:`Thank you for connecting with ${i}`,recipientName:e.name,introText:"Thank you for your interest in our products and services. A dedicated representative from our team will review your requirements and reach out to you shortly.",customBodyHtml:`
      <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin: 16px 0;">
        <p style="margin: 0 0 8px; font-weight: 600; color: #0f172a;">What happens next?</p>
        <ul style="margin: 0; padding-left: 20px; color: #475569; font-size: 14px; line-height: 1.6;">
          <li>Our team is reviewing your information.</li>
          <li>We will connect via phone or email to discuss how we can help.</li>
          <li>In the meantime, feel free to explore our offerings or reply to this email.</li>
        </ul>
      </div>
    `})}function D(t,e){const i=(t==null?void 0:t.name)||"Assay Biz";return`👋 *Hello ${e.name||"there"}, Welcome to ${i}!*

Thank you for your interest in our solutions. We have successfully registered your inquiry${e.company?` for *${e.company}*`:""}.

A dedicated representative from our team will get in touch with you shortly to assist you with the best options tailored to your needs.

In the meantime, feel free to reply directly to this chat if you have any questions!

Warm regards,
*Team ${i}*
📞 ${(t==null?void 0:t.phone)||"Customer Support"}`}async function z({org:t,deal:e,stage:i}){if(!(!(t!=null&&t.id)||!(e!=null&&e.id)))try{const{data:r,error:l}=await p.from("crm_automations").select("*").eq("org_id",t.id).eq("trigger_event","deal_won").eq("is_active",!0);if(l||!r||r.length===0)return;let n="Valued Customer",o=null,s=null;if(e.client_id){const{data:a}=await p.from("clients").select("display_name, email, phone, company_name").eq("id",e.client_id).maybeSingle();a&&(n=a.display_name||a.company_name||n,o=a.email||null,s=a.phone||null)}if(!o&&e.lead_id){const{data:a}=await p.from("leads").select("name, email, phone, company").eq("id",e.lead_id).maybeSingle();a&&(n==="Valued Customer"&&(n=a.name||n),o||(o=a.email||null),s||(s=a.phone||null))}if(r.some(a=>a.action_type==="send_deal_won_email")&&o){const a=`🎉 Congratulations & Welcome to ${t.name||"Assay Biz"}! Deal Confirmed: ${e.title}`,m=$(t,e,{name:n,email:o});p.functions.invoke("send-custom-email",{body:{to:o,subject:a,html:m,orgId:t.id}}).catch(d=>console.error("Error dispatching deal won email:",d)),await p.from("activities").insert({org_id:t.id,activity_type:"email",subject:`Auto Email: Deal Won Onboarding sent to ${o}`,body:`Automated congratulatory email dispatched for deal: "${e.title}" (Value: ${e.amount||0})`,opportunity_id:e.id,client_id:e.client_id||null,lead_id:e.lead_id||null,completed_at:new Date().toISOString()}),T.success(`Deal Won welcome email sent to ${o}!`)}if(r.some(a=>a.action_type==="send_deal_won_whatsapp")&&s){const a=w(t,e,{name:n,phone:s});await b({orgId:t.id,phone:s,message:a}),await p.from("activities").insert({org_id:t.id,activity_type:"whatsapp",subject:`Auto WhatsApp: Deal Won Message sent to ${s}`,body:a,opportunity_id:e.id,client_id:e.client_id||null,lead_id:e.lead_id||null,completed_at:new Date().toISOString()})}}catch(r){console.error("Failed to run deal won automation:",r)}}async function M({org:t,lead:e}){if(!(!(t!=null&&t.id)||!e))try{const{data:i}=await p.from("crm_automations").select("*").eq("org_id",t.id).eq("trigger_event","lead_created").eq("is_active",!0);if(!i||i.length===0)return;if(i.some(n=>n.action_type==="send_email")&&e.email){const n=`Welcome to ${(t==null?void 0:t.name)||"Assay Biz"}, ${e.name||"Partner"}!`,o=x(t,e);p.functions.invoke("send-custom-email",{body:{to:e.email,subject:n,html:o,orgId:t.id}}).catch(s=>console.error("Error sending lead welcome email:",s)),e.id&&await p.from("activities").insert({org_id:t.id,activity_type:"email",subject:`Auto Email: Welcome Email sent to ${e.email}`,body:"Automated CRM lead welcome email dispatched.",lead_id:e.id,completed_at:new Date().toISOString()})}if(i.some(n=>n.action_type==="send_whatsapp")&&e.phone){const n=D(t,e);await b({orgId:t.id,phone:e.phone,message:n}),e.id&&await p.from("activities").insert({org_id:t.id,activity_type:"whatsapp",subject:`Auto WhatsApp: Greeting sent to ${e.phone}`,body:n,lead_id:e.id,completed_at:new Date().toISOString()})}}catch(i){console.error("Failed to run lead created automation:",i)}}function g(t,e,i){var a,m,d;const r=(t==null?void 0:t.name)||"Assay Biz",l=e.due_at?new Date(e.due_at).toLocaleString("en-IN",{day:"numeric",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}):"Immediate",n=e.priority||"Medium",o=e.activity_type||"Follow-up",s=e.leadName||((a=e.lead)==null?void 0:a.name),u=e.leadCompany||((m=e.lead)==null?void 0:m.company),c=e.dealTitle||((d=e.opportunity)==null?void 0:d.title);return`⏰ *TASK DUE REMINDER — SALES ACTION REQUIRED*

Hi *${i.name||"Sales Executive"}*${i.role?` (${i.role})`:""},

Your scheduled CRM task is *Due Now / Approaching Deadline*:

📌 *Task Title:* ${e.subject||e.title||"CRM Task"}
🏷️ *Task Type:* ${o}
⚡ *Priority:* ${n}
⏰ *Due Date & Time:* ${l}
${s?`👤 *Customer / Lead:* ${s}${u?` (${u})`:""}
`:""}${c?`💼 *Opportunity:* ${c}
`:""}${e.body?`📝 *Notes:* ${e.body}
`:""}🏢 *Organization:* ${r}

👉 *Action Needed:* Please connect with the client or execute this task promptly, and update status in your CRM dashboard.`}function S(t,e,i){var a,m,d;const r=(t==null?void 0:t.name)||"Assay Biz",l=e.due_at?new Date(e.due_at).toLocaleString("en-IN",{day:"numeric",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}):"Immediate",n=e.priority||"Medium",o=e.activity_type||"Follow-up",s=e.leadName||((a=e.lead)==null?void 0:a.name),u=e.leadCompany||((m=e.lead)==null?void 0:m.company),c=e.dealTitle||((d=e.opportunity)==null?void 0:d.title);return _({logoUrl:(t==null?void 0:t.logo_url)||"https://aassaybiz.com/email-logo.png",companyName:r,companyEmail:(t==null?void 0:t.email)||"support@aassaybiz.com",badgeText:"TASK DUE DEADLINE · SALES ACTION",title:`Task Due Reminder: ${e.subject||e.title||"CRM Task"}`,subtitle:`Scheduled task has reached its due deadline in ${r}`,recipientName:i.name,introText:"This is an automated notification that an assigned sales task has reached or is approaching its deadline.",details:[{label:"Task Title",value:e.subject||e.title||"Sales Task",isHighlight:!0},{label:"Task Type",value:o},{label:"Priority",value:n,isHighlight:n==="Urgent"||n==="High"},{label:"Due Date & Time",value:l,isHighlight:!0},...s?[{label:"Related Lead",value:`${s}${u?` (${u})`:""}`}]:[],...c?[{label:"Related Deal",value:c}]:[]],customBodyHtml:`
      ${e.body?`
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; margin: 16px 0;">
          <p style="margin: 0 0 4px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase;">Task Description / Instructions:</p>
          <p style="margin: 0; font-size: 14px; color: #0f172a; line-height: 1.5;">${e.body}</p>
        </div>
      `:""}
      <div style="background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 14px; margin-top: 16px; text-align: center;">
        <p style="margin: 0; font-size: 13px; color: #1e40af; font-weight: 600;">
          Please log into your CRM Dashboard -> Calendar / Activities to complete this task and update status.
        </p>
      </div>
    `})}function v(t,e,i){var d,y,h,f;const r=(t==null?void 0:t.name)||"Assay Biz",l=e.due_at?new Date(e.due_at).toLocaleString("en-IN",{day:"numeric",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}):"Immediate",n=e.custom_reminder_at||((d=e.reminder_type)!=null&&d.startsWith("custom:")?e.reminder_type.slice(7):null),o=n?new Date(n).toLocaleString("en-IN",{day:"numeric",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}):"Scheduled Reminder",s=e.priority||"Medium",u=e.activity_type||"Follow-up",c=e.leadName||((y=e.lead)==null?void 0:y.name),a=e.leadCompany||((h=e.lead)==null?void 0:h.company),m=e.dealTitle||((f=e.opportunity)==null?void 0:f.title);return`🔔 *CUSTOM TASK REMINDER — AUTO NOTIFICATION*

Hi *${i.name||"Sales Executive"}*${i.role?` (${i.role})`:""},

This is your scheduled *Custom Reminder* for the following CRM task:

📌 *Task Title:* ${e.subject||e.title||"CRM Task"}
🏷️ *Task Type:* ${u}
⚡ *Priority:* ${s}
⏰ *Task Due Date:* ${l}
⏱️ *Reminder Scheduled For:* ${o}
${c?`👤 *Customer / Lead:* ${c}${a?` (${a})`:""}
`:""}${m?`💼 *Opportunity / Deal:* ${m}
`:""}${e.body?`📝 *Notes & Instructions:* ${e.body}
`:""}🏢 *Organization:* ${r}

👉 *Status:* ${e.status||"Pending"}
Please check your CRM dashboard or Calendar to execute this task before the due time.`}function C(t,e,i){var d,y,h,f;const r=(t==null?void 0:t.name)||"Assay Biz",l=e.due_at?new Date(e.due_at).toLocaleString("en-IN",{day:"numeric",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}):"Immediate",n=e.custom_reminder_at||((d=e.reminder_type)!=null&&d.startsWith("custom:")?e.reminder_type.slice(7):null),o=n?new Date(n).toLocaleString("en-IN",{day:"numeric",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}):"Scheduled Reminder",s=e.priority||"Medium",u=e.activity_type||"Follow-up",c=e.leadName||((y=e.lead)==null?void 0:y.name),a=e.leadCompany||((h=e.lead)==null?void 0:h.company),m=e.dealTitle||((f=e.opportunity)==null?void 0:f.title);return _({logoUrl:(t==null?void 0:t.logo_url)||"https://aassaybiz.com/email-logo.png",companyName:r,companyEmail:(t==null?void 0:t.email)||"support@aassaybiz.com",badgeText:"CUSTOM REMINDER · SALES TASK",title:`Custom Task Reminder: ${e.subject||e.title||"CRM Task"}`,subtitle:`Scheduled custom reminder alert triggered for ${i.name}`,recipientName:i.name,introText:`This automated custom reminder was scheduled for ${o} to alert you about an upcoming task due on ${l}.`,details:[{label:"Task Title",value:e.subject||e.title||"Sales Task",isHighlight:!0},{label:"Task Type",value:u},{label:"Priority",value:s,isHighlight:s==="Urgent"||s==="High"},{label:"Due Date & Time",value:l,isHighlight:!0},{label:"Custom Reminder At",value:o},...c?[{label:"Related Lead",value:`${c}${a?` (${a})`:""}`}]:[],...m?[{label:"Related Deal",value:m}]:[]],customBodyHtml:`
      ${e.body?`
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; margin: 16px 0;">
          <p style="margin: 0 0 4px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase;">Task Description / Instructions:</p>
          <p style="margin: 0; font-size: 14px; color: #0f172a; line-height: 1.5;">${e.body}</p>
        </div>
      `:""}
      <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 14px; margin-top: 16px; text-align: center;">
        <p style="margin: 0; font-size: 13px; color: #166534; font-weight: 600;">
          Log into your CRM Dashboard -> Calendar / Activities to review details and update task status once completed.
        </p>
      </div>
    `})}async function A({org:t,activity:e,assignee:i}){var r;if(!(!i||!(t!=null&&t.id)))try{const{data:l}=await p.from("crm_automations").select("*").eq("org_id",t.id),n=(r=e.reminder_type)==null?void 0:r.startsWith("custom:"),o=a=>{if(!l||l.length===0)return!0;const m=l.find(d=>d.action_type===a);return m?m.is_active:!0},s=o(n?"send_custom_reminder_whatsapp":"send_task_due_whatsapp"),u=o(n?"send_custom_reminder_email":"send_task_due_email"),c=e.subject||e.title||"CRM Task";if(s&&i.phone){const a=n?v(t,e,i):g(t,e,i);b({orgId:t.id,phone:i.phone,message:a}).catch(m=>console.error("Error sending activity WA reminder:",m))}if(u&&i.email){const a=n?`🔔 Custom Task Reminder: ${c} (${e.priority||"Medium"} Priority)`:`⏰ Task Due Reminder: ${c} (${e.priority||"Medium"} Priority)`,m=n?C(t,e,i):S(t,e,i);p.functions.invoke("send-custom-email",{body:{to:i.email,subject:a,html:m,orgId:t.id}}).catch(d=>console.error("Error sending activity Email reminder:",d))}}catch(l){console.error("Error executing task reminder automation:",l)}}function E(t){if(!t.due_at||!t.reminder_type||t.reminder_type==="none")return null;if(t.reminder_type.startsWith("custom:")){const i=t.reminder_type.slice(7),r=new Date(i);return isNaN(r.getTime())?null:r}const e=new Date(t.due_at);return isNaN(e.getTime())?null:t.reminder_type==="10_min"?new Date(e.getTime()-10*60*1e3):t.reminder_type==="1_hour"?new Date(e.getTime()-60*60*1e3):t.reminder_type==="1_day"?new Date(e.getTime()-24*60*60*1e3):null}async function O(t){if(t!=null&&t.id)try{const e=new Date,{data:i,error:r}=await p.from("activities").select("*, leads(name, company), opportunities(title)").eq("org_id",t.id).neq("reminder_type","none").not("owner_id","is",null).neq("status","Completed").is("completed_at",null).limit(50);if(r||!i||i.length===0)return;const{data:l}=await p.from("crm_team").select("*").eq("org_id",t.id).eq("is_active",!0),n=new Map;(l||[]).forEach(o=>n.set(o.id,o));for(const o of i){const s=E(o);if(!s)continue;const u=e.getTime()-s.getTime();if(u>=0&&u<=2*60*60*1e3){const a=`crm_reminder_sent_${o.id}_${o.reminder_type}`;if(localStorage.getItem(a))continue;const m=n.get(o.owner_id);m&&(await A({org:t,activity:o,assignee:m}),localStorage.setItem(a,new Date().toISOString()))}}}catch(e){console.error("Error in checkAndProcessDueTaskReminders:",e)}}export{z as a,$ as b,O as c,S as d,C as e,x as f,E as g,w as h,g as i,v as j,D as k,A as s,M as t};

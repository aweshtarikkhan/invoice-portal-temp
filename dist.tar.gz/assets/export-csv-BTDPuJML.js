function j(e,s){if(!e.length)return;const o=Object.keys(e[0]),r=[o.join(","),...e.map(i=>o.map(a=>{const n=i[a]??"";return`"${(typeof n=="object"?JSON.stringify(n):String(n)).replace(/"/g,'""')}"`}).join(","))],l=new Blob([r.join(`
`)],{type:"text/csv"}),c=URL.createObjectURL(l),t=document.createElement("a");t.href=c,t.download=`${s}.csv`,t.click(),URL.revokeObjectURL(c)}export{j as d};

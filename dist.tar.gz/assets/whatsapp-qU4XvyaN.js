import{R as a,s as l}from"./index-D2VlZDL9.js";const s="https://aassaybiz.com/api";function c(t,n="91"){if(!t)return"";const e=t.replace(/\D/g,"");return e?e.length===10?n+e:e:""}async function d(t){if(!t.orgId||!t.phone){a({title:"Error",description:"Missing organization or phone number.",variant:"destructive"});return}const n=c(t.phone);try{const e=await fetch(`${s}/message/send`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({org_id:t.orgId,phone:n,text:t.message})});if(!e.ok){const o=await e.json().catch(()=>({}));a({title:"Failed to Send",description:o.error||"Please check your WhatsApp connection.",variant:"destructive"});return}a({title:"WhatsApp Sent!",description:"Message dispatched successfully."})}catch(e){console.error(e),a({title:"Error",description:e.message||"Failed to reach WhatsApp service.",variant:"destructive"})}}const u={invoice:[`Hello {{client_name}},

Please find your invoice *{{document_no}}* for {{total}} (due {{due_date}}).

View & pay online: {{portal_link}}

Thank you,
{{org_name}}`,`Hi {{client_name}},

Your invoice {{document_no}} for the amount of {{total}} has been generated. 
Items:
{{items}}

Subtotal: {{subtotal}}
Tax: {{tax}}
Discount: {{discount}}
TDS: {{tds}}
Adjustment: {{adjustment}}
*Total: {{total}}*

You can view or download it here: {{portal_link}}

Regards,
{{org_name}}`],estimate:[`Hello {{client_name}},

Please find your quotation *{{document_no}}* for {{total}}.

View online: {{portal_link}}

Thank you,
{{org_name}}`,`Hi {{client_name}},

We have created a quotation {{document_no}} for you. The quoted total is {{total}}.

You can review it here: {{portal_link}}

Regards,
{{org_name}}`],purchase_order:[`Hello {{client_name}},

Please find our Purchase Order *{{document_no}}* for {{total}}.

View online: {{portal_link}}

Thank you,
{{org_name}}`,`Hi {{client_name}},

We have issued Purchase Order {{document_no}} for the amount of {{total}}.

You can review the PO here: {{portal_link}}

Regards,
{{org_name}}`],bill:[`Hello {{client_name}},

We have recorded your bill *{{document_no}}* for {{total}} (due {{due_date}}).

Thank you,
{{org_name}}`,`Hi {{client_name}},

Bill {{document_no}} for the amount of {{total}} has been entered into our system.

Regards,
{{org_name}}`]};async function p(t,n){var e;try{const{data:o}=await l.from("whatsapp_templates").select("content").eq("org_id",t).eq("type",n).eq("is_default",!0).maybeSingle();if(o!=null&&o.content)return o.content}catch(o){console.error("Error fetching template",o)}return((e=u[n])==null?void 0:e[0])||""}function _(t,n){let e=t;const o={"[Client Name]":n.client_name,"[Invoice Number]":n.document_no,"[Estimate Number]":n.document_no,"[Quotation Number]":n.document_no,"[PO Number]":n.document_no,"[Bill Number]":n.document_no,"[Total Amount]":n.total,"[Due Date]":n.due_date,"[Portal Link]":n.portal_link,"[Company Name]":n.org_name};for(const[i,r]of Object.entries(n))r!=null&&(e=e.split(`{{${i}}}`).join(String(r)));for(const[i,r]of Object.entries(o))r!=null?e=e.split(i).join(String(r)):e=e.split(i).join("");return e=e.replace(/{{[^}]+}}/g,""),n.portal_link&&!e.includes(n.portal_link)&&(e+=`

Link: ${n.portal_link}`),e.trim()}export{u as D,_ as c,p as g,c as n,d as o};

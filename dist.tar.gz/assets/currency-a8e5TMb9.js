function n(r,e){return new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR"}).format(r)}export{n as f};
